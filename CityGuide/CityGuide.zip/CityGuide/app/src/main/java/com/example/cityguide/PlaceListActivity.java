package com.example.cityguide;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class PlaceListActivity extends Activity {
    ListView listView;
    ArrayList<Place> places;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_list);

        listView = findViewById(R.id.place_list);
        dbHelper = new DBHelper(this);

        String category = getIntent().getStringExtra("category");

        places = dbHelper.getPlacesByCategory(category);

        ArrayAdapter<Place> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                places
        );

        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Place selectedPlace = places.get(position);

            Intent intent = new Intent(PlaceListActivity.this, PlaceDetailActivity.class);
            intent.putExtra("name", selectedPlace.name);
            intent.putExtra("description", selectedPlace.description);
            intent.putExtra("image", selectedPlace.imageName);
            startActivity(intent);




        });
    }
}
