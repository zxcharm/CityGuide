package com.example.cityguide;

public class Place {
    public String name;
    public String category;
    public String description;
    public String imageName;

    public Place(String name, String category, String description, String imageName) {
        this.name = name;
        this.category = category;
        this.description = description;
        this.imageName = imageName;
    }

    @Override
    public String toString() {
        return name; // чтобы в списке показывалось только имя места
    }
}
