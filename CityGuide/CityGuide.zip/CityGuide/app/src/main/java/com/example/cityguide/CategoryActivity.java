package com.example.cityguide;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class CategoryActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category); // подключаем макет activity_category.xml

        // Ищем кнопки по их ID из XML
        Button buttonParks = findViewById(R.id.button_parks);
        Button buttonMonuments = findViewById(R.id.button_monuments);

        // Устанавливаем действия по нажатию на кнопки
        buttonParks.setOnClickListener(v -> openPlaceList("парк"));
        buttonMonuments.setOnClickListener(v -> openPlaceList("памятник"));
    }

    // Метод для перехода на следующий экран и передачи выбранной категории
    private void openPlaceList(String category) {
        Intent intent = new Intent(this, PlaceListActivity.class);
        intent.putExtra("category", category);
        startActivity(intent);
    }
}
