package com.example.cityguide;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "places.db";
    private static final int DATABASE_VERSION = 2; // ВАЖНО: увеличено с 1 до 2

    public static final String TABLE_NAME = "places";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_CATEGORY = "category";
    public static final String COLUMN_DESCRIPTION = "description";
    public static final String COLUMN_IMAGE = "imageName";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Создание таблицы с полем imageName
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_NAME + " TEXT," +
                COLUMN_CATEGORY + " TEXT," +
                COLUMN_DESCRIPTION + " TEXT," +
                COLUMN_IMAGE + " TEXT)");

        // Вставка данных
        insertPlace(db, "Парк Зарядье", "парк", "Первый крупный парк Москвы за последние 70 лет. С концертным залом и подземной парковкой.", "zaryadye");
        insertPlace(db, "Воробьевы горы", "парк", "Лесопарк на высоком берегу Москвы-реки. Один из семи холмов столицы.", "vorobyovy");
        insertPlace(db, "Памятник Пушкину", "памятник", "Открыт в 1880 году. В честь великого русского поэта. Идея появилась в 1837.", "pushkin");
        insertPlace(db, "Памятник Карлу Марксу", "памятник", "Монумент из гранита на Театральной площади. Установлен в годы СССР.", "marx");
    }

    private void insertPlace(SQLiteDatabase db, String name, String category, String description, String imageName) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_CATEGORY, category);
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_IMAGE, imageName);
        db.insert(TABLE_NAME, null, values);
    }

    public ArrayList<Place> getPlacesByCategory(String category) {
        ArrayList<Place> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_NAME, null, COLUMN_CATEGORY + "=?",
                new String[]{category}, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
                String desc = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION));
                String imageName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_IMAGE));
                list.add(new Place(name, category, desc, imageName));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return list;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Удаление старой таблицы при обновлении и пересоздание
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
